using Microsoft.AspNetCore.Mvc;

namespace Controllers;

public class UsersController : Controller{

    public IActionResult Index(){
        return View();
    }
    public IActionResult Create(){
        return View();
    }
    public IActionResult Show(){
        return View();
    }
    public IActionResult Delete(){
        return View();
    }
    public IActionResult Update(){
        return View();
    }
    public IActionResult Edit(){
        return View();
    }
}