using Microsoft.EntityFrameworkCore;
using simulacro.Models;

namespace simulacro.Data;

public class BaseContext : DbContext{
    public BaseContext(DbContextOptions<BaseContext> options) : base(options){

    }

    public DbSet<Company> Companies { get; set;}

    public DbSet<Sector> Sectors { get; set; }
}