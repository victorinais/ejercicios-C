using Microsoft.AspNetCore.Http.Features;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using simulacro.Data;
using simulacro.Models;

namespace simulacro.Controllers;

public class CompaniesController : Controller {
    public readonly BaseContext _context;

    public CompaniesController(BaseContext context){
        _context = context;
    }
    //ver listado de Items
    public async Task<IActionResult> Index(){
        return View(await _context.Companies.ToListAsync());
    }

    //Mostrar vista para Crear
    public IActionResult Create(){
        return View();
    }

    //Crear un nuevo Item y Guardar en BD
    [HttpPost]
    public async Task<IActionResult> Create(Company company){
        _context.Companies.Add(company);
        _context.SaveChanges();
        return RedirectToAction("Index");
    }

    //Mostrar Detalles segun ID
    public async Task<IActionResult> Details(int? id){
        return View(await _context.Companies.FirstOrDefaultAsync(v => v.Id == id));
    }

    //Eliminar por id
    public async Task<IActionResult> Delete(int id){
        var item = await _context.Companies.FindAsync(id);
        _context.Companies.Remove(item);
        await _context.SaveChangesAsync();
        return RedirectToAction("Index");
    }

    //Llenar la vista edit y guardar en db
    public async Task<IActionResult> Edit(int? id){
        return View(await _context.Companies.FirstOrDefaultAsync(x => x.Id == id));
    }
    [HttpPost]
    public IActionResult Edit(int id, Company company){
        _context.Companies.Update(company);
        _context.SaveChanges();
        return RedirectToAction("Index");
    }

    //Buscador
    public IActionResult Buscar(string searchString)
    {
        var items = _context.Companies.AsQueryable();
        if (!string.IsNullOrEmpty(searchString))
        {
            items = items.Where(u => u.Name.Contains(searchString));
        }
        return View("Index", items.ToList());
    }

}