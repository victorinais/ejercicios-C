using Microsoft.AspNetCore.Http.Features;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using simulacro.Data;
using simulacro.Models;

namespace simulacro.Controllers;

public class SectorsController : Controller {

    public readonly BaseContext _context;

    public SectorsController(BaseContext context)
    {
        _context = context;
    }

    //ver listado de Items
    public async Task<IActionResult> Index(){
        return View(await _context.Sectors.ToListAsync());
    }

    //Mostrar vista para Crear
    public IActionResult Create()
    {
        return View();
    }

    //Crear un nuevo Item y Guardar en BD
    [HttpPost]
    public async Task<IActionResult> Create(Sector sector)
    {
        _context.Sectors.Add(sector);
        _context.SaveChanges();
        return RedirectToAction("Index");
    }

    //Mostrar Detalles segun ID
    public async Task<IActionResult> Details(int? id)
    {
        return View(await _context.Sectors.FirstOrDefaultAsync(v => v.Id == id));
    }

    //Eliminar por id
    public async Task<IActionResult> Delete(int id)
    {
        var item = await _context.Sectors.FindAsync(id);
        _context.Sectors.Remove(item);
        await _context.SaveChangesAsync();
        return RedirectToAction("Index");
    }

    //Llenar la vista edit y guardar en db
    public async Task<IActionResult> Edit(int? id)
    {
        return View(await _context.Sectors.FirstOrDefaultAsync(x => x.Id == id));
    }
    [HttpPost]
    public IActionResult Edit(int id, Sector sector)
    {
        _context.Sectors.Update(sector);
        _context.SaveChanges();
        return RedirectToAction("Index");
    }

    //Buscador
    public IActionResult Buscar(string searchString)
    {
        var items = _context.Sectors.AsQueryable();
        if (!string.IsNullOrEmpty(searchString))
        {
            items = items.Where(u => u.Name.Contains(searchString));
        }
        return View("Index", items.ToList());
    }

}