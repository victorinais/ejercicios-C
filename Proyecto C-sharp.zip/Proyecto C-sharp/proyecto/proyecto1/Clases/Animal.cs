namespace Clases {
    public class Animal{

        protected string Color = "black";
        public string tamaño = "mediano";
        public string Raza = "perro";
        public string Estado = "vivo";
        public int Patas = 4;

        public string Respirar(){
            return Estado;
        }
        public int Correr(){
            return Patas;
        }
    }
}