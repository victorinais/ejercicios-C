namespace Clases {

    public class Persona{
        public string Nombres = "julian";
        public string Apellidos = "perez";
        public string Correo = "julian@gmail.com";
        public int Edad = 25;


        public string MostrarDatos(){
            return  Nombres + " " + Apellidos + " " + Correo + " " + Edad;
        }

        public string ActualizarDatos(string newNombres, string newApellidos, string newCorreo, int newEdad){
            return newNombres + " " + newApellidos + " " + newCorreo + " " + newEdad;
        }
    }


}