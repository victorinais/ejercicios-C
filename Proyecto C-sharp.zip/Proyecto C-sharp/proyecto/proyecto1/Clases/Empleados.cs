namespace Clases {

     public class Empleado : Persona{

        public string CodigoEmpleado = "h212";
        public int Salario = 20000;

        public int CalcularSalario(){
            return Salario;
        }
        
    }
    
}