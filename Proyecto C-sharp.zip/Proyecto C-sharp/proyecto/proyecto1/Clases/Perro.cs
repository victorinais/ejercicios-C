namespace Clases {

    public class Perro : Animal{
        
        public string Comunicacion = "ladrar";

        public string Ladrar(){
            return Color;
        }
    }
}