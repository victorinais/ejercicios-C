namespace Clases {
    
      public class Gato : Animal{
        public string Comunicacion = "maullar";
        
        public string Maullar(){
            return Comunicacion;
        }
    }
}