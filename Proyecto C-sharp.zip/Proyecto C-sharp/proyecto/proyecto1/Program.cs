using Clases;

var builder = WebApplication.CreateBuilder(args);
var app = builder.Build();

app.MapGet("/", () => "Hello World!");

app.MapGet("calculadora/sumar", () => {
    Calculadora calculadora = new Calculadora();
    return calculadora.Sumar(1, 2);
});

app.MapGet("calculadora/restar", () => {
    Calculadora calculadora = new Calculadora();
    return calculadora.Restar(1, 2);
});

app.MapGet("calculadora/multiplicar", () => {
    Calculadora calculadora = new Calculadora();
    return calculadora.Multiplicar(5, 2);
});

app.MapGet("calculadora/dividir", () => {
    Calculadora calculadora = new Calculadora();
    return calculadora.Dividir(1, 2);
});

app.Run();
