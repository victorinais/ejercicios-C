using Clases;

var builder = WebApplication.CreateBuilder(args);
var app = builder.Build();

app.MapGet("/", () => "Hello World!");

app.MapGet("calculadora/sumar", () => {
    Calculadora calculadora = new Calculadora();
    return calculadora.Sumar(1, 2);
});

app.MapGet("calculadora/restar", () => {
    Calculadora calculadora = new Calculadora();
    return calculadora.Restar(1, 2);
});

app.MapGet("calculadora/multiplicar", () => {
    Calculadora calculadora = new Calculadora();
    return calculadora.Multiplicar(5, 2);
});

app.MapGet("calculadora/dividir", () => {
    Calculadora calculadora = new Calculadora();
    return calculadora.Dividir(1, 2);
});

//ejercicios

app.MapGet("saludo", () => {
    Saludo saludo = new Saludo();
    return saludo.Datos("Juan", "Pérez");
});

app.MapGet("contarPalabras", () => {
    ContarPalabras contarPalabras = new ContarPalabras();
    return contarPalabras.Contador("Hoy es un día muy frío");
});

//persona

app.MapGet("/mostrar-datos", () => {
    Persona mostrar = new Persona();
    return mostrar.MostrarDatos();
});

app.MapGet("/salario", () => {
    Empleado empleado = new Empleado();
    return empleado.CalcularSalario();
});

app.MapGet("/puntos", () => {
    Cliente popo = new Cliente();
    return popo.CalcularPuntos();
});

app.MapGet("/color", ()=> {
    Perro perro = new Perro();
    return perro.Ladrar();
});

app.Run();
