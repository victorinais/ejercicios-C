
using Microsoft.AspNetCore.Mvc;


namespace GHV.Controllers.User
{
    public class UserController : Controller
    {

        public IActionResult Usuario()
        {
            return View();
        }

        public IActionResult InformacionAcademica()
        {
            return View();
        }
        public IActionResult InformacionLaboral()
        {
            return View();
        }
        public IActionResult Habilidades()
        {
            return View();
        }
        public IActionResult InformacionPersonal()
        {
            return View();
        }
    
    }
}