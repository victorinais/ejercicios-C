﻿// See https://aka.ms/new-console-template for more information
//pedir primer numero
/* Console.WriteLine("Ingrese el primer número");
string valor1 = Console.ReadLine();
int.TryParse(valor1, out int num1);
//pedir segundo numero
Console.WriteLine("Ingrese el segundo número");
string valor2 = Console.ReadLine();
int.TryParse(valor2, out int num2);
//hacer comparaciones
if(num1 % 2 == 0 && num2 % 2  == 0){
    Console.WriteLine("los dos numeros son pares");
}else if(num1 % 2 > 0 && num2 % 2 > 0){
    Console.WriteLine("los dos numeros son impares");
}else if(num1 % 2 > 0){
    Console.WriteLine("el primer numero es impar, el segundo es par");
}else if(num2 % 2 > 0){
    Console.WriteLine("el primer numero es par, el segundo numero es impar");
} */
//-------------------------------------------------------------------------------------------
//solicitar edad
/* Console.Write("ingrese su edad: ");
string valor3 = Console.ReadLine();
int.TryParse(valor3, out int edad);
//solicitar genero y comprobar
string genero = "";
do{
    Console.Write("ingrese su genero (M)masculino (F)femenino: ");
    string input = Console.ReadLine();
    genero = input.ToUpper();
}while(genero != "M" && genero != "F");
//hacer comparaciones
if(genero == "M" && edad >= 60 || genero == "F" && edad >= 55){
    Console.WriteLine("apto para jubilarse");
}else{
    Console.WriteLine("no se puede jubilar");
} */
//----------------------------------------------------------------------------------------------
//solicitar año
/* Console.Write("Ingrese un año: ");
string valor5 = Console.ReadLine();
int.TryParse(valor5, out int ano);

bool esBiciesto = (ano % 4 == 0 && ano % 100 != 0) || (ano % 400 == 0);

if (esBiciesto == true){
    Console.WriteLine($"El año {ano} es bisiesto");
}else{
    Console.WriteLine($"El año {ano} No es bisiesto");
} */
//------------------------------------------------------------------------------------------------
//solicitar nombre
/* Console.Write("ingrese su nombre: ");
string nombre = Console.ReadLine();
//solicitar edad
Console.Write("ingrese su edad: ");
string valor7 = Console.ReadLine();
int.TryParse(valor7, out int edad);
//hacer condiciones
if(edad < 18 || edad > 60){
    Console.WriteLine("puede obtener un descuento");
}else{
    Console.WriteLine("No puede obtener descuento");
} */
//-------------------------------------------------------------------------------------------------
//solicitar nombre de usuario
/* Console.Write("ingrese el nombre de usuario: ");
string nombreUsuario = Console.ReadLine();
//solicitar contraseña
Console.Write("ingrese la contraseña: ");
string valor8 = Console.ReadLine();
int.TryParse(valor8, out int password);
//se crean las credenciales
string usuario = "admin";
int contraseña = 1234;
//se hacen las comparaciones
if(nombreUsuario == usuario && contraseña == password){
    Console.WriteLine("Acceso concedido");
}else{
    Console.WriteLine("Acceso denegado");
} */
//---------------------------------------------------------------------------------------------------
//solicitar numeros
/* Console.WriteLine("Ingrese el primer numero");
int valor9 = Convert.ToInt32(Console.ReadLine());
Console.WriteLine("Ingrese el segundo numero");
int valor10 = Convert.ToInt32(Console.ReadLine());
Console.WriteLine("Ingrese el tercer numero");
int valor11 = Convert.ToInt32(Console.ReadLine());
//hacer condiciones
if(valor9 < 0 && valor10 > 0 && valor11 > 0){
    Console.WriteLine($"el primer numero {valor9} es negativo");
}else if(valor10 < 0 && valor9 > 0 && valor11 > 0){
    Console.WriteLine($"el segundo numero {valor10} es negativo");
}else if(valor11 < 0 && valor9 > 0 && valor10 > 0){
    Console.WriteLine($"el tercer numero {valor11} es negativo");
}else if(valor9 > 0 && valor10 > 0 && valor11 > 0){
    Console.WriteLine("todos los numeros son positivos");
}else if(valor9 < 0 && valor10 < 0 && valor11 < 0){
    Console.WriteLine("todos los numeros son negativos");
} */
//-----------------------------------------------------------------------------------------------------
//solicitar temperatura en grados celsius
/* Console.Write("ingrese la temperatura en grados celsius y la convertiré en grados fahrenheit: ");
string dato = Console.ReadLine();
// Primera comprobación: si el dato es vacío o nulo
if (string.IsNullOrEmpty(dato)){
    Console.WriteLine("El dato no puede ser vacío o nulo.");
    return;
}
// Segunda comprobación: si el dato es un número
if (!int.TryParse(dato, out int numero)){
    Console.WriteLine("El dato no es un número válido.");
    return;
}
//conversion de celsius a fahrenheit
int resultado = numero * 9/5 + 32;
Console.WriteLine($"El dato ingresado es: {numero}°C convertido a grados fahrenheit es: {resultado}°F"); */
//-------------------------------------------------------------------------------------------------------
//solicitar mes 
/* Console.Write("Ingrese una de las siguientes opciones: 1 para enero, 2 para febrero, 3 para marzo, 4 para abril, 5 mayo, 6 para junio, 7 para julio, 8 para agosto, 9 para septiembre, 10 para octubre, 11 noviembre y 12 para diciembre: ");
int mes = Convert.ToInt32(Console.ReadLine());
if(mes < 1 || mes > 12){
    Console.WriteLine("El numero ingresado no corresponde a una de las opciones.");
    return;
}
switch (mes){
    case 10:
    Console.WriteLine("Este mes corresponde a halloween");
    break;
    case 12:
    Console.WriteLine("Este mes corresponde a navidad");
    break;
    default:
    Console.WriteLine("El mes ingresado no corresponde a ninguna festividad");
    break;
} */
//-----------------------------------------------------------------------------------------------------------
// Pedir al usuario que ingrese las longitudes de los lados
/* Console.WriteLine("Ingrese la longitud del lado A:");
double ladoA = double.Parse(Console.ReadLine());
Console.WriteLine("Ingrese la longitud del lado B:");
double ladoB = double.Parse(Console.ReadLine());
Console.WriteLine("Ingrese la longitud del lado C:");
double ladoC = double.Parse(Console.ReadLine());

// Validar que la suma de dos lados cualquiera sea mayor que el tercer lado
if (ladoA + ladoB <= ladoC || ladoA + ladoC <= ladoB || ladoB + ladoC <= ladoA){
    Console.WriteLine("Las longitudes ingresadas no forman un triángulo válido.");
    return;
}
// Determinar el tipo de triángulo
if (ladoA == ladoB && ladoB == ladoC){
    Console.WriteLine("El triángulo es equilátero.");
}else if (ladoA == ladoB || ladoA == ladoC || ladoB == ladoC){
    Console.WriteLine("El triángulo es isósceles.");
}else{
    Console.WriteLine("El triángulo es escaleno.");
} */
//-----------------------------------------------------------------------------------------------------------
// Pedir numeros al usuario
/* Console.Write("Ingrese el primer número: ");
int num1 = int.Parse(Console.ReadLine());
Console.Write("Ingrese el segundo número: ");
int num2 = int.Parse(Console.ReadLine());
 Console.Write("Ingrese el tercer número: ");
int num3 = int.Parse(Console.ReadLine());

// Verificar si todos los números son menores a 10
if (num1 < 10 && num2 < 10 && num3 < 10){
    Console.WriteLine("Todos los números son menores a diez.");
}else{
    Console.WriteLine("Al menos un número no es menor a diez.");
} */
//---------------------------------------------------------------------------------------------------
// Pedir el valor de la factura
/* Console.Write("Ingrese el valor total de la factura: ");
double montoFactura = double.Parse(Console.ReadLine());
// Pedir el porcentaje de propina
Console.Write("Ingrese el porcentaje de propina que desea dejar: ");
double porcentajePropina = double.Parse(Console.ReadLine());

// Calcular el valor de la propina
double montoPropina = montoFactura * porcentajePropina / 100;

// Calcular el total a pagar
double totalPagar = montoFactura + montoPropina;

// Mostrar el valor de la propina y el total a pagar
Console.WriteLine($"Monto de la propina: {montoPropina:C2}");
Console.WriteLine($"Total a pagar: {totalPagar:C2}"); */
//----------------------------------------------------------------------------------------------------
//solicitar precio
/* Console.Write("Ingrese el precio del producto: ");
double precio = double.Parse(Console.ReadLine());
//solicitar descuento
Console.Write("Ingrese el descuento: ");
double descuento = double.Parse(Console.ReadLine());

descuento = precio * descuento / 100;
double total = precio - descuento;

Console.WriteLine($"el total a pagar con el descuento aplicado es: {total}"); */
//----------------------------------------------------------------------------------------------------
//pedir valores
/* Console.WriteLine("Ingrese 3 valores iguales.");
Console.Write("Ingrese el primer valor: ");
int num1 = int.Parse(Console.ReadLine());
Console.Write("Ingrese el segundo valor: ");
int num2 = int.Parse(Console.ReadLine());
Console.Write("Ingrese el tercer valor: ");
int num3 = int.Parse(Console.ReadLine());

if(num1 == num2 && num1 == num3){
    int suma = num1 + num2;
    int multiplicacion = suma * num3;
    Console.WriteLine($"El resultado es {multiplicacion}");
}else{
    Console.WriteLine("Los numeros ingresados no son iguales.");
} */
//------------------------------------------------------------------------------------------------------
//solicitar datos
Console.Write("Ingrese el sueldo que recibe actualmente en la compañia: ");
double sueldo = double.Parse(Console.ReadLine());
Console.Write("Ingrese el numero de años que lleva trabajando en la compañia: ");
int antiguedad = int.Parse(Console.ReadLine());

if(sueldo < 500 && antiguedad >= 10){
    double aumento = sueldo * 20 / 100;
    double totalPago = sueldo + aumento;
    Console.WriteLine($"Gracias a los {antiguedad} años de antiguedad usted ha recibido un aumneto de {aumento:C2} y su sueldo es {totalPago:C2}");
}else if(sueldo < 500 && antiguedad < 10){
    double aumento = sueldo * 5 / 100;
    double totalPago = sueldo + aumento;
    Console.WriteLine($"Gracias a los {antiguedad} años de antiguedad usted ha recibido un aumneto de {aumento:C2} y su sueldo es {totalPago:C2}");
}else if(sueldo >= 500){
    Console.WriteLine($"Su sueldo es de {sueldo:C2}");
}


