﻿// See https://aka.ms/new-console-template for more information
//pedir primer numero
/* Console.WriteLine("Ingrese el primer número");
string valor1 = Console.ReadLine();
int.TryParse(valor1, out int num1);
//pedir segundo numero
Console.WriteLine("Ingrese el segundo número");
string valor2 = Console.ReadLine();
int.TryParse(valor2, out int num2);
//hacer comparaciones
if(num1 % 2 == 0 && num2 % 2  == 0){
    Console.WriteLine("los dos numeros son pares");
}else if(num1 % 2 > 0 && num2 % 2 > 0){
    Console.WriteLine("los dos numeros son impares");
}else if(num1 % 2 > 0){
    Console.WriteLine("el primer numero es impar, el segundo es par");
}else if(num2 % 2 > 0){
    Console.WriteLine("el primer numero es par, el segundo numero es impar");
} */
//---------------------------------------------------------------------------
//solicitar edad
/* Console.Write("ingrese su edad: ");
string valor3 = Console.ReadLine();
int.TryParse(valor3, out int edad);
//solicitar genero y comprobar
string genero = "";
do{
    Console.Write("ingrese su genero (M)masculino (F)femenino: ");
    string input = Console.ReadLine();
    genero = input.ToUpper();
}while(genero != "M" && genero != "F");
//hacer comparaciones
if(genero == "M" && edad >= 60 || genero == "F" && edad >= 55){
    Console.WriteLine("apto para jubilarse");
}else{
    Console.WriteLine("no se puede jubilar");
} */
//---------------------------------------------------------------------------
//solicitar año
Console.Write("Ingrese un año: ");
string valor5 = Console.ReadLine();
int.TryParse(valor5, out int ano);

bool esBiciesto = (ano % 4 == 0 && ano % 100 != 0) || (ano % 400 == 0);

if (esBiciesto == true){
    Console.WriteLine($"El año {ano} es bisiesto");
}else{
    Console.WriteLine($"El año {ano} No es bisiesto");
}
//---------------------------------------------------------------------------


