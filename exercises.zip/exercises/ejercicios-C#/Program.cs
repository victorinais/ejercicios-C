﻿// See https://aka.ms/new-console-template for more information
//pedir primer numero
/* Console.WriteLine("Ingrese el primer número");
string valor1 = Console.ReadLine();
int.TryParse(valor1, out int num1);
//pedir segundo numero
Console.WriteLine("Ingrese el segundo número");
string valor2 = Console.ReadLine();
int.TryParse(valor2, out int num2);
//hacer comparaciones
if(num1 % 2 == 0 && num2 % 2  == 0){
    Console.WriteLine("los dos numeros son pares");
}else if(num1 % 2 > 0 && num2 % 2 > 0){
    Console.WriteLine("los dos numeros son impares");
}else if(num1 % 2 > 0){
    Console.WriteLine("el primer numero es impar, el segundo es par");
}else if(num2 % 2 > 0){
    Console.WriteLine("el primer numero es par, el segundo numero es impar");
} */
//---------------------------------------------------------------------------
//solicitar edad
/* Console.Write("ingrese su edad: ");
string valor3 = Console.ReadLine();
int.TryParse(valor3, out int edad);
//solicitar genero y comprobar
string genero = "";
do{
    Console.Write("ingrese su genero (M)masculino (F)femenino: ");
    string input = Console.ReadLine();
    genero = input.ToUpper();
}while(genero != "M" && genero != "F");
//hacer comparaciones
if(genero == "M" && edad >= 60 || genero == "F" && edad >= 55){
    Console.WriteLine("apto para jubilarse");
}else{
    Console.WriteLine("no se puede jubilar");
} */
//---------------------------------------------------------------------------
//solicitar año
/* Console.Write("Ingrese un año: ");
string valor5 = Console.ReadLine();
int.TryParse(valor5, out int ano);

bool esBiciesto = (ano % 4 == 0 && ano % 100 != 0) || (ano % 400 == 0);

if (esBiciesto == true){
    Console.WriteLine($"El año {ano} es bisiesto");
}else{
    Console.WriteLine($"El año {ano} No es bisiesto");
} */
//---------------------------------------------------------------------------
//solicitar nombre
/* Console.Write("ingrese su nombre: ");
string nombre = Console.ReadLine();
//solicitar edad
Console.Write("ingrese su edad: ");
string valor7 = Console.ReadLine();
int.TryParse(valor7, out int edad);
//hacer condiciones
if(edad < 18 || edad > 60){
    Console.WriteLine("puede obtener un descuento");
}else{
    Console.WriteLine("No puede obtener descuento");
} */
//--------------------------------------------------------------------------
//solicitar nombre de usuario
/* Console.Write("ingrese el nombre de usuario: ");
string nombreUsuario = Console.ReadLine();
//solicitar contraseña
Console.Write("ingrese la contraseña: ");
string valor8 = Console.ReadLine();
int.TryParse(valor8, out int password);
//se crean las credenciales
string usuario = "admin";
int contraseña = 1234;
//se hacen las comparaciones
if(nombreUsuario == usuario && contraseña == password){
    Console.WriteLine("Acceso concedido");
}else{
    Console.WriteLine("Acceso denegado");
} */
//--------------------------------------------------------------------------
//solicitar numeros
Console.WriteLine("Ingrese el primer numero");
int valor9 = Convert.ToInt32(Console.ReadLine());
Console.WriteLine("Ingrese el segundo numero");
int valor10 = Convert.ToInt32(Console.ReadLine());
Console.WriteLine("Ingrese el tercer numero");
int valor11 = Convert.ToInt32(Console.ReadLine());
//hacer condiciones
if(valor9 < 0 && valor10 > 0 && valor11 > 0){
    Console.WriteLine($"el primer numero {valor9} es negativo");
}else if(valor10 < 0 && valor9 > 0 && valor11 > 0){
    Console.WriteLine($"el segundo numero {valor10} es negativo");
}else if(valor11 < 0 && valor9 > 0 && valor10 > 0){
    Console.WriteLine($"el tercer numero {valor11} es negativo");
}else if(valor9 > 0 && valor10 > 0 && valor11 > 0){
    Console.WriteLine("todos los numeros son positivos");
}else if(valor9 < 0 && valor10 < 0 && valor11 < 0){
    Console.WriteLine("todos los numeros son negativos");
}


