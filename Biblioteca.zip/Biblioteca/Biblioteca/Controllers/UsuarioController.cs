using Microsoft.AspNetCore.Mvc;

namespace Biblioteca.Controllers;

public class UsuarioController : Controller
{
    public IActionResult Crear()
    {
        return View();
    }

    public IActionResult Actualizar()
    {
        return View();
    }


    public IActionResult Ver()
    {
        return View();
    }

    public IActionResult Eliminar()
    {
        return View();
    }

}