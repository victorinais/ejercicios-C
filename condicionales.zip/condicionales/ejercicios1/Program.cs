﻿// See https://aka.ms/new-console-template for more information
/* Console.Write("Ingrese un numero: ");
int numero = int.Parse(Console.ReadLine());
if(numero > 0){
    Console.WriteLine("el numero es positivo");
}else{
    Console.WriteLine("el numero es negativo");
} */
//---------------------------------------------------------------
/* Console.Write("Ingrese un numero: ");
int numero = int.Parse(Console.ReadLine());
if(numero < 0){
    Console.WriteLine("el numero es negativo");
}else{
    Console.WriteLine("el numero es positivo");
} */
//------------------------------------------------------------------
/* Console.Write("Ingrese un numero: ");
int numero = int.Parse(Console.ReadLine());

if(numero % 2 == 0){
    Console.WriteLine("el numero es par");
}else{
    Console.WriteLine("el numero es impar");
} */
/* //----------------------------------------------------------------
Console.Write("Ingrese un numero: ");
int numero = int.Parse(Console.ReadLine());

if(numero % 2 != 0){
    Console.WriteLine("el numero es impar");
}else{
    Console.WriteLine("el numero es par");
} */
//------------------------------------------------------------------
/* Console.Write("Ingrese un numero: ");
int numero = int.Parse(Console.ReadLine());

if(numero % 5 == 0){
    Console.WriteLine("el numero es multiplo de 5");
}else{
    Console.WriteLine("el numero no es multiplo de 5");
} */
//------------------------------------------------------------------
/* Console.Write("Ingrese un numero: ");
int numero = int.Parse(Console.ReadLine());

if(numero % 3 == 0){
    Console.WriteLine("el numero es divisible entre 3");
}else{
    Console.WriteLine("el numero no es divisible entre 3");
} */
//------------------------------------------------------------------
/* Console.Write("Ingrese un numero: ");
int numero = int.Parse(Console.ReadLine());

if(numero > 100){
    Console.WriteLine("el numero es mayor a 100");
}else{
    Console.WriteLine("el numero es menor a 100");
} */
//------------------------------------------------------------------
/* Console.Write("Ingrese un numero: ");
int numero = int.Parse(Console.ReadLine());

if(numero < 50){
    Console.WriteLine("el numero es menor a 50");
}else{
    Console.WriteLine("el numero es mayor a 50");
} */
//-------------------------------------------------------------------
/* Console.Write("Ingrese un numero: ");
int numero = int.Parse(Console.ReadLine());

if(numero >= 20 && numero <= 50){
    Console.WriteLine("el numero está entre 20 y 50");
}else{
    Console.WriteLine("el numero no está en el rango");
} */
//-------------------------------------------------------------------
/*  Console.Write("Ingrese un numero: ");
int numero = int.Parse(Console.ReadLine());

if(numero == 0){
    Console.WriteLine("el numero es igual a cero");
}else{
    Console.WriteLine("el numero es diferente de cero");
} */
//-------------------------------------------------------------------
/* Console.Write("Ingrese un numero: ");
int numero = int.Parse(Console.ReadLine());

if(numero > -10 && numero < 10){
    Console.WriteLine("el numero está dentro del rango");
}else{
    Console.WriteLine("el numero no está dentro del rango");
} */
//-------------------------------------------------------------------
/* Console.Write("Ingrese un numero: ");
int numero = int.Parse(Console.ReadLine());

bool bisiesto = (numero % 4 == 0 && numero != 100) || (numero % 400 == 0);

if(bisiesto == true){
    Console.WriteLine($"el {numero} es bisiesto");
}else{
    Console.WriteLine($"el {numero} es no es bisiesto");
} */
//--------------------------------------------------------------------
/* Console.Write("Ingrese su edad: ");
int edad = int.Parse(Console.ReadLine());

if(edad >= 18){
    Console.WriteLine("La persona es mayor de edad");
}else{
    Console.WriteLine("La persona es menor de edad");
}*/
//---------------------------------------------------------------------
/* Console.Write("Ingrese un numero: ");
int numero = int.Parse(Console.ReadLine());

if(numero > -10 && numero < 10){
    Console.WriteLine("el numero está dentro del rango");
}else{
    Console.WriteLine("el numero no está dentro del rango");
} */
//---------------------------------------------------------------------
/* Console.Write("Ingrese un numero: ");
double numero = double.Parse(Console.ReadLine());

double raizCuadrada = Math.Sqrt(numero);

if(raizCuadrada % 1 == 0){
    Console.WriteLine($"El {numero} es un cuadrado perfecto");
}else{
    Console.WriteLine($"El {numero} no es un cuadrado perfecto");
} */
//----------------------------------------------------------------------
/* Console.Write("Ingrese un numero: ");
int numero = int.Parse(Console.ReadLine());

int anterior = 0;
int actual = 1;
int fibonacci = 0;

while(fibonacci < numero){
    fibonacci = anterior + actual;
    if(fibonacci == numero){
        Console.WriteLine($"el {numero} es fibonacci");
    }else if(fibonacci > numero){
        Console.WriteLine($"el {numero} No es fibonacci");
    }
    anterior = actual;
    actual = fibonacci;
} */
//---------------------------------------------------------------------
/* Console.Write("Ingrese un numero: ");
int numero = int.Parse(Console.ReadLine());

if (numero == 0){
    Console.WriteLine("Ingrese un numero diferente de cero.");
}else if (numero > 0){
    bool resultado = Math.Log2(numero) % 1 == 0;
    if(resultado == true){
        Console.WriteLine($"{numero} es potencia de 2");
    }else{
        Console.WriteLine($"{numero} no es potencia de 2");
    }
} */
//-------------------------------------------------------------------------
/* Console.Write("Ingrese un numero: ");
string numero = Console.ReadLine();

string numeroInvertido = "";

for(int i = numero.Length -1; i >= 0; i--){
    Console.WriteLine(numero[i]);
    numeroInvertido += numero[i];
}

if(numero == numeroInvertido){
    Console.WriteLine($"El {numero} es un palindromo");
}else{
    Console.WriteLine($"El {numero} no es un palindromo");
} */
//---------------------------------------------------------------------------
/* Console.Write("Ingrese un texto: ");
string valor1 = Console.ReadLine();

string texto = valor1.ToLower();
string palabra = "javascript";

bool encontrado = texto.Contains(palabra);

if(encontrado){
    Console.WriteLine($"El texto contiene la palabra {palabra}");
}else{
    Console.WriteLine($"El texto No contiene la palabra {palabra}");
} */
//------------------------------------------------------------------------------
/* Console.Write("Ingrese un texto y te diré si tiene mas de 10 caracteres: ");
string texto = Console.ReadLine();

if(texto.Length > 10){
    Console.WriteLine("El texto contiene mas de 10 caracteres");
}else{
    Console.WriteLine("El texto contiene menos de 10 caracteres");
} */
//------------------------------------------------------------------------------
/* Console.Write("Ingrese un texto: ");
string texto = Console.ReadLine();

string textoMinusculas = texto.ToLower();

if(texto == textoMinusculas){
    Console.WriteLine("El texto está en minusculas");
}else{
    Console.WriteLine("El texto no está en minusculas");
} */
//--------------------------------------------------------------------------------
/* Console.Write("Ingrese un texto: ");
string texto = Console.ReadLine();

bool contieneNumero = texto.Any(char.IsDigit);

if(contieneNumero){
    Console.WriteLine("El texto ingresado contiene almenos un numero");
}else{
    Console.WriteLine("El texto ingresado no contiene numeros");
} */
//---------------------------------------------------------------------------------
/* Console.Write("Ingrese un texto: ");
string texto = Console.ReadLine();

bool terminaEn = texto.EndsWith(".");

if(terminaEn){
    Console.WriteLine("El texto ingresado ternmina en punto");
}else{
    Console.WriteLine("El texto ingresado no termina en punto");
} */
//----------------------------------------------------------------------------------
/* Console.Write("Ingrese un texto: ");
string valor = Console.ReadLine();
string texto = valor.ToLower();
string alfabeto = "mnbvcxzasdfghjklñpoiuytrewq";

int[] frecuenciaLetras = new int[alfabeto.Length];

for(int i = 0;i < texto.Length; i++){
    char letra = texto[i];
    int indice = alfabeto.IndexOf(letra);
    if(indice != -1){
        frecuenciaLetras[indice]++;
    }
}
bool esPangrama = true;
for(int i = 0; i < frecuenciaLetras.Length; i++){
    if(frecuenciaLetras[i] == 0){
        esPangrama = false;
        break;
    }
}
if(esPangrama){
    Console.WriteLine("el texto es un pangrama");
}else{
    Console.WriteLine("el texto no es un pangrama");
} */
//---------------------------------------------------------------------------------------------------------------------------------------------------------
/* Console.Write("Ingrese un dia de la semana: 1 para lunes, 2 para martes, 3 para miercoles, 4 jueves, 5 para viernes, 6 para sabado y 7 para domingo: ");
int dia = int.Parse(Console.ReadLine());

switch (dia)
{
    case 6:
        Console.WriteLine("día No laborable");
        break;
    case 7:
        Console.WriteLine("día No laborable");
        break;
    default:
        Console.WriteLine("día laborable");
        break;
} */
//------------------------------------------------------------------------------------------
/* Console.Write("Ingrese un dia de la semana: ");
string valor = Console.ReadLine();
string dia = valor.ToLower();
if(dia.Any(char.IsDigit)){
    Console.WriteLine("Ingrese solo letras no numeros");
    return;
}else if(dia != "lunes" && dia != "martes" && dia != "miercoles" && dia != "jueves" && dia != "viernes" && dia != "sabado" && dia != "domingo"){
    Console.WriteLine("Ingrese un dia de la semana valido");
    return;
}
switch (dia)
{
    case "sabado":
    Console.WriteLine("Este es un dia de fin de semana - es sabado");
    break;
    case "domingo":
    Console.WriteLine("Este es un dia de fin de semana - es domingo");
    break;
    default:
    Console.WriteLine("Este es un dia de semana");
    break;
} */
//----------------------------------------------------------------------------------------------
/* Console.Write("Ingrese el numero correspondiente al mes del año: ");
int mes = int.Parse(Console.ReadLine());

if(mes > 12 || mes < 1){
    Console.WriteLine("Este mes es invalido, esta fuera del rango");
}else{
    Console.WriteLine("Este mes es valido");
}
 */
//--------------------------------------------------------------------------------------------
/* Console.WriteLine("Ingrese la hora en el siguiente formato hora:minutos am/pm: ");
string valor = Console.ReadLine();
string horaTexto = valor.ToUpper();

DateTime hora = DateTime.Parse(horaTexto);
int hora24 = hora.Hour;
if(hora.ToString("tt") == "PM"){
    hora24 += 12;
}
bool estaEnRango = hora24 >= 9 && hora24 <= 18;

if(estaEnRango){
    Console.WriteLine("La hora está entre 9 am y 6 pm");
}else{
    Console.WriteLine("La hora NO está entre 9 am y 6 pm");
} */
//-----------------------------------------------------------------------------------------------
/* Console.Write("Ingrese su edad: ");
int edad = int.Parse(Console.ReadLine());

if(edad < 18){
    Console.WriteLine("Es menor de 18 años");
}else if(edad > 65){
    Console.WriteLine("Es mayor a 65 años");
}else{
    Console.WriteLine("la edad está entre 18 y 65");
} */
//----------------------------------------------------------------------------------------------
/* Console.WriteLine("Ingrese la primer medida de un lado del triangulo: ");
double lado1 = double.Parse(Console.ReadLine());

Console.WriteLine("Ingrese la segunda medida de un lado del triangulo: ");
double lado2 = double.Parse(Console.ReadLine());

Console.WriteLine("Ingrese la tercer medida de un lado del triangulo: ");
double lado3 = double.Parse(Console.ReadLine());

if(lado1 == lado2 && lado1 == lado3){
    Console.WriteLine("El triangulo es equilátero");
}else{
    Console.WriteLine("El triangulo No es equilátero");
} */
//---------------------------------------------------------------------------------------------
/* Console.Write("Ingrese la primer medida de un lado del triángulo: ");
double lado1 = double.Parse(Console.ReadLine());

Console.Write("Ingrese la segunda medida de un lado del triángulo: ");
double lado2 = double.Parse(Console.ReadLine());

Console.Write("Ingrese la tercer medida de un lado del triángulo: ");
double lado3 = double.Parse(Console.ReadLine());

if(lado1 == lado2 || lado1 == lado3 || lado2 == lado3){
    Console.WriteLine("El triángulo es isósceles");
}else{
    Console.WriteLine("El triángulo No es isósceles");
} */
//-----------------------------------------------------------------------------------------------
/* Console.Write("Ingrese la primer medida de un lado del triángulo: ");
double lado1 = double.Parse(Console.ReadLine());

Console.Write("Ingrese la segunda medida de un lado del triángulo: ");
double lado2 = double.Parse(Console.ReadLine());

Console.Write("Ingrese la tercer medida de un lado del triángulo: ");
double lado3 = double.Parse(Console.ReadLine());

if(lado1 != lado2 && lado1 != lado3){
    Console.WriteLine("El triángulo es escaleno");
}else{
    Console.WriteLine("El triángulo No es escaleno");
} */
//------------------------------------------------------------------------------------------------
/* Console.Write("Ingrese un número: ");
int num1 = int.Parse(Console.ReadLine());

Console.Write("Ingrese otro número: ");
int num2 = int.Parse(Console.ReadLine());

if(num1 == (num2 * 2)){
    Console.WriteLine($"El {num1} es igual al doble de {num2}");
}else if(num1 > (num2 * 2)){
    Console.WriteLine($"El {num1} es mayor al doble de {num2}");
}else{
    Console.WriteLine($"El {num1} es menor al doble de {num2}");
} */
//--------------------------------------------------------------------------------------------------
Console.WriteLine("Ingresa el primer numero:");
int num1 = int.Parse(Console.ReadLine());

Console.WriteLine("Ingrese el segundo numero: ");
int num2 = int.Parse(Console.ReadLine());

int suma = num1 + num2;

if(suma == 100){
    Console.WriteLine("La suma de los dos numeros es igual a 100");
}else if(suma > 100){
    Console.WriteLine("La suma de los dos numeros es mayor a 100");
}else{
    Console.WriteLine("La suma de los dos numeros es menor a 100");
}