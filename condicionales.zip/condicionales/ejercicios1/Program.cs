﻿// See https://aka.ms/new-console-template for more information
/* Console.Write("Ingrese un numero: ");
int numero = int.Parse(Console.ReadLine());
if(numero > 0){
    Console.WriteLine("el numero es positivo");
}else{
    Console.WriteLine("el numero es negativo");
} */
//---------------------------------------------------------------
/* Console.Write("Ingrese un numero: ");
int numero = int.Parse(Console.ReadLine());
if(numero < 0){
    Console.WriteLine("el numero es negativo");
}else{
    Console.WriteLine("el numero es positivo");
} */
//------------------------------------------------------------------
/* Console.Write("Ingrese un numero: ");
int numero = int.Parse(Console.ReadLine());

if(numero % 2 == 0){
    Console.WriteLine("el numero es par");
}else{
    Console.WriteLine("el numero es impar");
} */
/* //----------------------------------------------------------------
Console.Write("Ingrese un numero: ");
int numero = int.Parse(Console.ReadLine());

if(numero % 2 != 0){
    Console.WriteLine("el numero es impar");
}else{
    Console.WriteLine("el numero es par");
} */
//------------------------------------------------------------------
/* Console.Write("Ingrese un numero: ");
int numero = int.Parse(Console.ReadLine());

if(numero % 5 == 0){
    Console.WriteLine("el numero es multiplo de 5");
}else{
    Console.WriteLine("el numero no es multiplo de 5");
} */
//------------------------------------------------------------------
/* Console.Write("Ingrese un numero: ");
int numero = int.Parse(Console.ReadLine());

if(numero % 3 == 0){
    Console.WriteLine("el numero es divisible entre 3");
}else{
    Console.WriteLine("el numero no es divisible entre 3");
} */
//------------------------------------------------------------------
/* Console.Write("Ingrese un numero: ");
int numero = int.Parse(Console.ReadLine());

if(numero > 100){
    Console.WriteLine("el numero es mayor a 100");
}else{
    Console.WriteLine("el numero es menor a 100");
} */
//------------------------------------------------------------------
/* Console.Write("Ingrese un numero: ");
int numero = int.Parse(Console.ReadLine());

if(numero < 50){
    Console.WriteLine("el numero es menor a 50");
}else{
    Console.WriteLine("el numero es mayor a 50");
} */
//-------------------------------------------------------------------
/* Console.Write("Ingrese un numero: ");
int numero = int.Parse(Console.ReadLine());

if(numero >= 20 && numero <= 50){
    Console.WriteLine("el numero está entre 20 y 50");
}else{
    Console.WriteLine("el numero no está en el rango");
} */
//-------------------------------------------------------------------
/*  Console.Write("Ingrese un numero: ");
int numero = int.Parse(Console.ReadLine());

if(numero == 0){
    Console.WriteLine("el numero es igual a cero");
}else{
    Console.WriteLine("el numero es diferente de cero");
} */
//-------------------------------------------------------------------
/* Console.Write("Ingrese un numero: ");
int numero = int.Parse(Console.ReadLine());

if(numero > -10 && numero < 10){
    Console.WriteLine("el numero está dentro del rango");
}else{
    Console.WriteLine("el numero no está dentro del rango");
} */
//-------------------------------------------------------------------
/* Console.Write("Ingrese un numero: ");
int numero = int.Parse(Console.ReadLine());

bool bisiesto = (numero % 4 == 0 && numero != 100) || (numero % 400 == 0);

if(bisiesto == true){
    Console.WriteLine($"el {numero} es bisiesto");
}else{
    Console.WriteLine($"el {numero} es no es bisiesto");
} */
//--------------------------------------------------------------------
/* Console.Write("Ingrese su edad: ");
int edad = int.Parse(Console.ReadLine());

if(edad >= 18){
    Console.WriteLine("La persona es mayor de edad");
}else{
    Console.WriteLine("La persona es menor de edad");
}*/
//---------------------------------------------------------------------
/* Console.Write("Ingrese un numero: ");
int numero = int.Parse(Console.ReadLine());

if(numero > -10 && numero < 10){
    Console.WriteLine("el numero está dentro del rango");
}else{
    Console.WriteLine("el numero no está dentro del rango");
} */
//---------------------------------------------------------------------
/* Console.Write("Ingrese un numero: ");
double numero = double.Parse(Console.ReadLine());

double raizCuadrada = Math.Sqrt(numero);

if(raizCuadrada % 1 == 0){
    Console.WriteLine($"El {numero} es un cuadrado perfecto");
}else{
    Console.WriteLine($"El {numero} no es un cuadrado perfecto");
} */
//----------------------------------------------------------------------
/* Console.Write("Ingrese un numero: ");
int numero = int.Parse(Console.ReadLine());

int anterior = 0;
int actual = 1;
int fibonacci = 0;

while(fibonacci < numero){
    fibonacci = anterior + actual;
    if(fibonacci == numero){
        Console.WriteLine($"el {numero} es fibonacci");
    }else if(fibonacci > numero){
        Console.WriteLine($"el {numero} No es fibonacci");
    }
    anterior = actual;
    actual = fibonacci;
} */
//---------------------------------------------------------------------
/* Console.Write("Ingrese un numero: ");
int numero = int.Parse(Console.ReadLine());

if (numero == 0){
    Console.WriteLine("Ingrese un numero diferente de cero.");
}else if (numero > 0){
    bool resultado = Math.Log2(numero) % 1 == 0;
    if(resultado == true){
        Console.WriteLine($"{numero} es potencia de 2");
    }else{
        Console.WriteLine($"{numero} no es potencia de 2");
    }
} */
//----------------------------------------------------------------------
Console.Write("Ingrese un numero: ");
string numero = Console.ReadLine();

string alContrario = "";

for(int i = numero.Length -1; i >= 0; i--){
    Console.WriteLine(numero[i]);
    
}

