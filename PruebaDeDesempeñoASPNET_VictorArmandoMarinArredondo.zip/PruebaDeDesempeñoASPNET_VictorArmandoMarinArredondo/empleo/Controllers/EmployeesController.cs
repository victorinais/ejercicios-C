using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using empleo.Data;
using empleo.Models;

namespace empleo.Controllers;

public class EmployeesController : Controller {
    public readonly BaseContext _Context;
    public EmployeesController(BaseContext context){
        _Context = context;
    }
    //Listar empleados
    public async Task<IActionResult> Index(){
        return View(await _Context.Employees.ToListAsync());
    }
    //Crear Empleado
    public IActionResult Create(){
        return View();
    }
    [HttpPost]
    public async Task<IActionResult> Create(Employee employee){
        _Context.Employees.Add(employee);
        _Context.SaveChanges();
        return RedirectToAction("Index");
    }
    //Detalles empleados
    public async Task<IActionResult> Details(int? id)
    {
        return View(await _Context.Employees.FirstOrDefaultAsync(x => x.Id == id));
    }
    //Editar empleado
    public async Task<IActionResult> Edit(int? id)
    {
        return View(await _Context.Employees.FirstOrDefaultAsync(x => x.Id == id));
    }
    [HttpPost]
    public IActionResult Edit(int id, Employee employee)
    {
        _Context.Employees.Update(employee);
        _Context.SaveChanges();
        return RedirectToAction("Index");
    }
    //Eliminar empleado
    public async Task<IActionResult> Delete(int? id)
    {
        var Item = await _Context.Employees.FindAsync(id);
        _Context.Employees.Remove(Item);
        await _Context.SaveChangesAsync();
        return RedirectToAction("Index");
    }
    //Buscador
    public IActionResult Buscar(string searchString)
    {
        var items = _Context.Employees.AsQueryable();
        if (!string.IsNullOrEmpty(searchString))
        {
            items = items.Where(u => u.Names.Contains(searchString) || u.LastNames.Contains(searchString) || u.Email.Contains(searchString) || u.About.Contains(searchString));
        }
        return View("Index", items.ToList());
    }
}