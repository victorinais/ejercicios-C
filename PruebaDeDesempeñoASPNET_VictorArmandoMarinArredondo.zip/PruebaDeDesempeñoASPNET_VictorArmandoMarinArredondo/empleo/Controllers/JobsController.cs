using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using empleo.Data;
using empleo.Models;

namespace empleo.Controllers;

public class JobsController : Controller{
    public readonly BaseContext _Context;
    public JobsController(BaseContext context)
    {
        _Context = context;
    }
    //Listar empleados
    public async Task<IActionResult> Index()
    {
        return View(await _Context.Jobs.ToListAsync());
    }
    //Crear Empleado
    public IActionResult Create()
    {
        return View();
    }
    [HttpPost]
    public async Task<IActionResult> Create(Job job)
    {
        _Context.Jobs.Add(job);
        _Context.SaveChanges();
        return RedirectToAction("Index");
    }
    //Eliminar empleado
    public async Task<IActionResult> Delete(int? id)
    {
        var Item = await _Context.Jobs.FindAsync(id);
        _Context.Jobs.Remove(Item);
        await _Context.SaveChangesAsync();
        return RedirectToAction("Index");
    }
}