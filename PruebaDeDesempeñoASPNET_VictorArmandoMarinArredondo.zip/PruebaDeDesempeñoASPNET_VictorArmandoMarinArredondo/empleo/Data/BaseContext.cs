using Microsoft.EntityFrameworkCore;
using empleo.Models;

namespace empleo.Data;
public class BaseContext : DbContext {
    public BaseContext(DbContextOptions<BaseContext> options) : base(options){

    }
    public DbSet<Employee> Employees { get; set; }
    public DbSet<Job> Jobs { get; set; }
}