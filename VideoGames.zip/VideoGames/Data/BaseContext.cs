using Microsoft.EntityFrameworkCore;
using VideoGames.Models;
namespace VideoGames.Data;

public class BaseContext : DbContext {
    public BaseContext(DbContextOptions<BaseContext> options) : base(options){

    }
    public DbSet<Inventario> Inventarios { get; set; }
}