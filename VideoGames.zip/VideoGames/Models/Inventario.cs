namespace Inventario.Models;

public class Inventario {
    public int Id { get; set; }
    public string Nombre { get; set; }
    public string Imagen { get; set; }
    public string Descripcion { get; set; }
    public int Cantidad { get; set; }
    public DateOnly FechaLanzamiento { get; set; }
    public string ConsolasCompatibles { get; set; }
    public bool JugableOnline { get; set; }
}