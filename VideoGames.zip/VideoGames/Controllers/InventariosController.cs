using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using VideoGames.Data;
using VideoGames.Models;
namespace VideoGames.Controllers;

public class InventariosController : Controller {
    public readonly BaseContext _context;
    public InventariosController(BaseContext context){
        _context = context;
    }
    //listar items
    public async Task<IActionResult> Index(){
        return View(await _context.Inventarios.ToListAsync());
    }
}