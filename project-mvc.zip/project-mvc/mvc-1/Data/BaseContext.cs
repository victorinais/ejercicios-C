using Microsoft.EntityFrameworkCore;
using mvc_1.Models;

namespace mvc_1.Data;

public class BaseContext : DbContext{

    public BaseContext(DbContextOptions<BaseContext> options) : base(options){

    }
    public DbSet<User> Users { get; set; }
}