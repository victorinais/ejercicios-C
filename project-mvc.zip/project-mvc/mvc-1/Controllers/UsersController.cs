using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using mvc_1.Data;
namespace mvc_1.Controllers;

public class UsersController : Controller {

    public readonly BaseContext _context;
    public UsersController(BaseContext context){

        _context = context;
    }
    public async Task<IActionResult> Index(){
        return View(await _context.Users.ToListAsync());
        //select * from users
    }

}