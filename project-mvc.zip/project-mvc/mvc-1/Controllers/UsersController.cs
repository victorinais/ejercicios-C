using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using mvc_1.Data;
namespace mvc_1.Controllers;

public class UsersController : Controller {

    public readonly BaseContext _context;
    public UsersController(BaseContext context){

        _context = context;
    }
    public async Task<IActionResult> Index(){
        var users = await _context.Users.ToListAsync();
        return View(users);
        //select * from users
    }
    public async Task<IActionResult> Details(int? id){
        return View(await _context.Users.FirstOrDefaultAsync(m => m.Id == id));
        //select * from users where id = ?
    }
    public IActionResult Delete(int? id){
        var delete = _context.Users.FirstOrDefault(m => m.Id == id);
        _context.Users.Remove(delete);
        _context.SaveChanges();
        return RedirectToAction("Index");
    }

    /* public async Task<IActionResult> Delete(int id){
        var user = await _context.Users.FindAsync(id);
        _context.Users.Remove(user);
    }
 */
}