namespace mvc_1.Models;

    public class User{

        public int id { get; set; }
        public string Names { get; set; }
        public string LastNames { get; set; }
        public string Email { get; set; }
    }
