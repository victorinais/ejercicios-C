using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MVC_2.Data;
namespace MVC_2.Controllers;

public class UsersController : Controller {
    public readonly BaseContext _Context;
    public UsersController(BaseContext context){
        _Context = context;
    }
    
}