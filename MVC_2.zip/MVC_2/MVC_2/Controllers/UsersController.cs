using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MVC_2.Data;
using MVC_2.Models;
namespace MVC_2.Controllers;

public class UsersController : Controller {
    public readonly BaseContext _Context;
    public UsersController(BaseContext context){
        _Context = context;
    }
    public async Task<IActionResult> Index(){
        return View(await _Context.Users.ToListAsync());
    }
    public async Task<IActionResult> Details(int? id){
        return View(await _Context.Users.FirstOrDefaultAsync(x => x.Id == id));
    }
    public async Task<IActionResult> Delete(int? id){
        var user = await _Context.Users.FindAsync(id);
        _Context.Users.Remove(user);
        await _Context.SaveChangesAsync();
        return RedirectToAction("Index");
    }
    [HttpPost]
    //[ValidateAntiForgeryToken]
    public async Task<IActionResult> Create([Bind("Names, LastNames, Email, BirthDate, Address, Phone")]User usuario){
        if(ModelState.IsValid){
            _Context.Users.Add(usuario);
            await _Context.SaveChangesAsync();
            return RedirectToAction("Index");
        }
        return View(usuario);
    }
    public async Task<IActionResult> Edit(int? id){
        return View(await _Context.Users.FirstOrDefaultAsync(x => x.Id == id));
    }
    [HttpPost]
    public IActionResult Edit(int id, User usuario){
        _Context.Users.Update(usuario);
        _Context.SaveChanges();
        return RedirectToAction("Index");
    }

    public IActionResult Buscar(string searchString){
        var users = _Context.Users.AsQueryable();
        if(!string.IsNullOrEmpty(searchString)){
            users = users.Where(u => u.Names.Contains(searchString) || u.LastNames.Contains(searchString));
        }
        return View("Index", users.ToList());
    }

}