using Microsoft.AspNetCore.Mvc;
using MVC_2.Data;
namespace MVC_2.Controllers;

public class ProductsController : Controller {
    public readonly BaseContext _Context;
    public ProductsController(BaseContext context)
    {
        _Context = context;
    }
}