using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MVC_2.Data;
namespace MVC_2.Controllers;

public class ProductsController : Controller {
    public readonly BaseContext _Context;
    public ProductsController(BaseContext context)
    {
        _Context = context;
    }
    public async Task<IActionResult> Index(){
        return View(await _Context.Products.ToListAsync());
    }
    public async Task<IActionResult> Details(int? id){
        return View(await _Context.Products.FirstOrDefaultAsync(x => x.Id == id));
    }
    public async Task<IActionResult> Delete(int? id){
        var product = await _Context.Products.FindAsync(id);
        _Context.Products.Remove(product);
        await _Context.SaveChangesAsync();
        return RedirectToAction("Index");
    }
}