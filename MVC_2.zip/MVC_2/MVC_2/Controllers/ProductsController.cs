using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MVC_2.Data;
using MVC_2.Models;
namespace MVC_2.Controllers;

public class ProductsController : Controller {
    public readonly BaseContext _Context;
    public ProductsController(BaseContext context)
    {
        _Context = context;
    }
    public async Task<IActionResult> Index(){
        return View(await _Context.Products.ToListAsync());
    }
    public async Task<IActionResult> Details(int? id){
        return View(await _Context.Products.FirstOrDefaultAsync(x => x.Id == id));
    }
    public async Task<IActionResult> Delete(int? id){
        var product = await _Context.Products.FindAsync(id);
        _Context.Products.Remove(product);
        await _Context.SaveChangesAsync();
        return RedirectToAction("Index");
    }
    [HttpPost]
    //[ValidateAntiForgeryToken]
    public async Task<IActionResult> Create([Bind("Name, Description, Price, Amount, ExpirationDate")] Product producto){
        if (ModelState.IsValid){
            _Context.Products.Add(producto);
            await _Context.SaveChangesAsync();
            return RedirectToAction("Index");
        }
        return View(producto);
    }
    public async Task<IActionResult> Edit(int? id)
    {
        return View(await _Context.Products.FirstOrDefaultAsync(x => x.Id == id));
    }
    [HttpPost]
    public IActionResult Edit(int id, Product producto)
    {
        _Context.Products.Update(producto);
        _Context.SaveChanges();
        return RedirectToAction("Index");
    }
}