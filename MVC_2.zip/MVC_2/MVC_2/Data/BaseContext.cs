using Microsoft.EntityFrameworkCore;
using MVC_2.Models;
namespace MVC_2.Data;

public class BaseContext : DbContext {

    public BaseContext(DbContextOptions<BaseContext> options) : base(options){

    }
    public DbSet<User> Users { get; set; }
    public DbSet<Product> Products { get; set; }
}